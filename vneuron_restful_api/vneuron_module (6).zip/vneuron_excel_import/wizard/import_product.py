# -*- coding: utf-8 -*-
import base64
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import itertools
from datetime import datetime
from odoo.osv import osv
import logging
_logger = logging.getLogger(__name__)

try:
    import xlrd
    try:
        from xlrd import xlsx
    except ImportError:
        xlsx = None
except ImportError:
    xlrd = xlsx = None

class LineImport(models.TransientModel):
    _name = 'import.product.line'
    _description = 'Import Product Line'

    data_file = fields.Binary(string='Product File', required=True,)
    filename = fields.Char()

    @api.multi
    def import_file(self):
        self.ensure_one()
        book = xlrd.open_workbook(file_contents=base64.b64decode(self.data_file))
        sheet = book.sheet_by_index(0)
        
        data_list=[]
        _logger.info("------mrisssa------data range(sheet.nrows)------%s",range(sheet.nrows))
        _logger.info("------mrisssa------data  sheet.nrows------%s",sheet.nrows)
        _logger.info("------mrisssa------data sheet.row------%s",sheet.row )
        for row in range(7,sheet.nrows):
            cells = sheet.row_slice(rowx=row,start_colx=1,end_colx=11)
            for cell in cells:
                _logger.info("------mrisssa------cell.value------%s",cell.value )
            data_list += [cells]
            
#         Product         = self.env['product.product']
        Product         = self.env['litige.brv']
        active_id       = self._context.get('active_id', False)
        active_model    = self._context.get('active_model', False)

        # Mua hang
        # Ravi Krishnan - change default_code to name
                        
        

        if active_model == 'litige.brv':
            litigeLine = self.env['litige.brvlines']
            for line in data_list:
                _logger.info("------mrisssa------data_list-line-----%s",line[0].value)
                _logger.info("------mrisssa------data_list------%s",line)
#                 product_id = Product.search([('default_code','=',line[0])],limit=1)
                so_line_id = litigeLine.create({
                    'brvline_id': active_id,
                    'code_article': line[0].value,
                    'libelle': line[1].value,
                    'line_vl': line[2].value,
                    'line_ul': line[3].value,
                    'line_qte': line[4].value,
                    'line_Montant': line[5].value,
                    'line_code_tva': line[6].value,
                    'line_tva': line[7].value,
                    'line_type_doc': line[8].value,
                    'line_doc': line[9].value,
                })
#                 so_line_id.product_id_change()
#                 so_line_id.product_uom_qty = int(line[1])
        
        if active_model == 'purchase.order':
            PurchaseLine = self.env['purchase.order.line']
            i = 0
            s = ''
            for line in data_list:
                i = i + 1
                _logger.debug("item checking = : %r", i)

                product_id = Product.search([('name','=',line[0])],limit=1)
                if product_id:
                    po_line_id = PurchaseLine.create({
                        'order_id': active_id,
                        'name': product_id.name,
                        'product_id': product_id.id,
                        'product_uom': product_id.uom_po_id.id,
                        'price_unit': 0,
                        'product_qty': 1,
                        'date_planned': datetime.today().strftime(DEFAULT_SERVER_DATETIME_FORMAT),
                    })
                    po_line_id.onchange_product_id()
                    po_line_id.product_qty = int(line[1])
                else:
                    _logger.debug("item not found checking = : %r", i)
                    s = s + " - " + str(i) 
                    _logger.debug("s is having value = :" + s)

            if s:        
                raise osv.except_osv(('Import of Excel File Failed'), ('Check Item on line(s) ' + s))    
                        

        # Ravi Krishnan - purchase requisition
        if active_model == 'purchase.requisition':
            PurchaseReqLine = self.env['purchase.requisition.line']
            i = 0
            s = ''
            for line in data_list:
                i = i + 1
                _logger.debug("item checking = : %r", i)
                
                product_id = Product.search([('name','=',line[0])],limit=1)
                if product_id:
                    pa_line_id = PurchaseReqLine.create({
                        'requisition_id': active_id,
                        'product_id': product_id.id,
                        'product_uom_id': product_id.uom_po_id.id,
                        'product_qty': 1,
                    })
                    pa_line_id.product_qty = int(line[1])
                else:
                    _logger.debug("item not found checking = : %r", i)
                    s = s + " - " + str(i) 
                    _logger.debug("s is having value = :" + s)

            if s:        
                raise osv.except_osv(('Import of Excel File Failed'), ('Check Item on line(s) ' + s))    

        # Chuyen kho
        if active_model == 'stock.picking':        
            picking = self.env['stock.picking'].browse(active_id)
            Move = self.env['stock.move']
            for line in data_list:
                product_id = Product.search([('default_code','=',line[0])],limit=1)
                move = Move.new({
                    'product_id': product_id.id,                     
                    'location_id': picking.location_id.id, 
                    'location_dest_id': picking.location_dest_id.id,
                })
                move.onchange_product_id()
                move_values = move._convert_to_write(move._cache)
                move_values.update({
                    'picking_id': active_id,
                    'product_uom_qty': int(line[1]),
                })
            Move.create(move_values)

        if active_model == 'stock.inventory':
            inventory = self.env['stock.inventory'].browse(active_id)
            InventoryLine = self.env['stock.inventory.line']
            for line in data_list:
                product_id = Product.search([('default_code','=',line[0])],limit=1)
                InventoryLine.create({
                    'inventory_id': active_id,
                    'product_id': product_id.id,
                    'product_uom_id': product_id.uom_id.id,
                    'location_id': inventory.location_id.id,
                    'product_qty': int(line[1]),
                })

        if active_model == 'sale.order':
            SaleOrderLine = self.env['sale.order.line']
            for line in data_list:
                product_id = Product.search([('default_code','=',line[0])],limit=1)
                so_line_id = SaleOrderLine.create({
                    'order_id': active_id,
                    'product_id': product_id.id,
                    'name': product_id.name,
                    'price_unit': 0,
                    'product_qty': 1,
                })
                so_line_id.product_id_change()
                so_line_id.product_uom_qty = int(line[1])

        if active_model == 'account.invoice':
            inv = self.env['account.invoice'].browse(active_id)
            InvoiceLine = self.env['account.invoice.line']
            ctx = {'journal_id': inv.journal_id.id}
            for line in data_list:
                product_id = Product.search([('default_code','=',line[0])],limit=1)
                inv_line_id = InvoiceLine.with_context(ctx).create({
                    'invoice_id': active_id,
                    'product_id': product_id.id,
                    'name': product_id.name,
                    'price_unit': 0,
                    'quantity': int(line[1]),
                })
                inv_line_id._onchange_product_id()

