# -*- coding: utf-8 -*-
{
    'name': 'Import line from Excel file',
    'version': '1.0',
    'summary': ' Vneuron Import line  from Excel file',
     
    'author': 'Mrissa Ali/ Vneuron',
    'website': 'https://vneuron.com',
    'images': [],
    'depends': [ ],
    'data': [
        'security/data.xml',
        'wizard/import_product_wizard.xml',
        'views/sales_view.xml',
#         'views/purchase_view.xml',
#         'views/invoice_view.xml',
#         'views/picking_view.xml',
#         'views/inventory_adjustment_view.xml',
#         'views/purchase_tender_view.xml'
    ],     

     'images': ['static/description/main.png'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
