# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import time
from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError
from datetime import datetime
class LitigeLitige(models.Model):

    _name = "litige.litige"
    _description = "Litige"
    

    @api.model
    def _get_default_name(self):
        return self.env['ir.sequence'].next_by_code('litige.litige')

    @api.one
    @api.depends('date_debut')
    def _compute_month(self):
        if self.date_debut:
            self.month = datetime.strftime(datetime.strptime(self.date_debut, "%Y-%m-%d"), '%m')

#     @api.multi
#     def _refund_count(self):
#         for each in self:
#             refund_ids = self.env['account.invoice'].search([('litige_id', '=', each.id)])
#             each.refund_count = len(refund_ids)
# 
#     @api.multi
#     def refund_view(self):
#         self.ensure_one()
#         domain = [
#             ('litige_id', '=', self.id),('type', '=', 'in_refund')]
#         return {
#             'name': _('Avoir'),
#             'domain': domain,
#             'context': {'default_type': 'in_refund', 'type': 'in_refund', 'account_invoice': True,
#                         'litige_id': self.id},
#             'res_model': 'account.invoice',
#             'type': 'ir.actions.act_window',
#             'view_id': False,
#             'view_mode': 'tree,form',
#             'view_type': 'form',
#             'help': _('''<p class="oe_view_nocontent_create">
#                                            
#                                         </p>'''),
#             'limit': 80,
#         }

#     @api.multi
#     def refund_create_view(self):
#         self.ensure_one()
#         domain = []
#         return {
#             'name': _('Avoir'),
#             'domain': domain,
#             'context':{'default_type':'in_refund', 'type':'in_refund', 'account_invoice': True, 'litige_id': self.id},
#             'res_model': 'account.invoice',
#             'type': 'ir.actions.act_window',
#             'view_id': False,
#             'view_mode': 'form',
#             'view_type': 'form',
#         }

    ref_sec = fields.Char('Ref Litige', size=32, default=_get_default_name,)
    name = fields.Char('Num Chrono', size=32, required=True)
    code_fourni =fields.Integer('Fournisseur', required=True)
    libelle =fields.Char('Libelle',size=255)
    ref_invoice = fields.Char('Ref Facture')
    rayon =fields.Integer('Rayon')
    type_line = fields.Many2one('litige.type', string="Type line")
    no_reception =fields.Char('No Reception', size=32) 
    no_commande =fields.Float('No Commande', size=32) 
    date_commnade = fields.Date(string="Date Commande", default= time.strftime('%Y-%m-%d'))
    date_reception = fields.Date(string="Date Reception", default= time.strftime('%Y-%m-%d'))
    montant_ht= fields.Float("Montant HT" )
    montant_ttc= fields.Float("Montant TTC" )
    code_site =fields.Integer('Site')
    source =fields.Selection([('facture', 'Facture'), ('autres', 'Autres')], string='Source',default='facture',
      help='sources des lignes letigeuses')
    supplier = fields.Many2one('res.partner', string="Fournisseur", domain=[('supplier', '=', True)])
    user = fields.Many2one('litige.acheteur', string="Affecter a acheteur")
#     invoice_id = fields.Many2one('account.invoice', string="Avoir") 
    note = fields.Text('Description')
    date_debut = fields.Date(string="Date Debut", default= time.strftime('%Y-%m-%d'))
    month = fields.Selection(
        [('01', 'Janvier'), ('02', 'fevrier'), ('03', 'Mars'), ('04', 'Avril'), ('05', 'Mai'), ('06', 'Juin'),
         ('07', 'Juillet'), ('08', 'Aout'), ('09', 'Septembre'), ('10', 'Octobre'), ('11', 'Novembre'),
         ('12', 'Decembre'), ], string='Mois', readonly=True, compute='_compute_month', store=True)
    date_fin = fields.Date(string="Date Fin")
    date_traiemant = fields.Date(string="Date traitement")
    cause = fields.Many2one('litige.type', string="Cause")
    line_ids = fields.One2many('litige.lines', 'litige_id', string="Categories de produit")
    state = fields.Selection(
        [('creer', 'Creer'), ('en_cours', 'En cours'), ('traiter', 'traiter'), ('cloturer', 'Cloturer')], 'Etat',
         default='creer')
    refund_count = fields.Integer( string='Avoir')

    @api.multi
    def act_en_cours(self):
        self.state = 'en_cours'

    @api.multi
    def act_traiter(self):
#         self.date_traiemant = time.strftime('%Y-%m-%d')
        self.state = 'traiter'

    @api.multi
    def act_cloturer(self):
#         self.date_fin = time.strftime('%Y-%m-%d')
        self.state = 'cloturer'
 

class LitigeType(models.Model):

    _name = "litige.type"
    _description = "Cause de litige"
    

    name = fields.Char('Type Litige')

class LitigeAcheteur(models.Model):

    _name = "litige.acheteur"
    _description = "agent d'achat / suppilant"
    
    fourninsseur = fields.Char('Nom Fournisseur')
    code_fourninsseur = fields.Char('Code Fournisseur')
    name= fields.Many2one('res.partner', string="Acheteur")
    suppleant_id = fields.Many2one('litige.suppleant', string="Suppléant")

class LitigeSuppleant(models.Model):

    _name = "litige.suppleant"
    _description = " suppilant"
    
    name= fields.Many2one('res.partner', string="Suppléant")
    agent_ids = fields.One2many('litige.acheteur', 'suppleant_id', string="Acheteurs")

class LitigeLigne(models.Model):
    @api.model
    def _get_default_name(self):
        return self.env['ir.sequence'].next_by_code('litige.ligne')
    
    
    _name = "litige.lines"
    _description = "litige.lines"
    

    name = fields.Char('Ref linge', size=32, default=_get_default_name,)
    litige_id = fields.Many2one('litige.litige', string="Litige")
    code_article = fields.Char('Code article', size=32,)
    libelle = fields.Char('Libelle', size=255,)
    line_vl = fields.Integer('VL')
    line_ul = fields.Char('UL', size=32,)
    line_qte = fields.Float('Quantite')
    line_Montant = fields.Float('Montant')
    line_code_tva = fields.Integer('Code T.V.A.')
    line_tva = fields.Float('T.V.A.')
    line_type_doc = fields.Integer('Type document')
    line_doc = fields.Char('Libelle doc.', size=32,)
#     line_traite = fields.boolean('Traite')
class LitigeBrv(models.Model):

    _name = "litige.brv"
    _description = "litige.brv"
    

    @api.model
    def _get_default_name(self):
        return self.env['ir.sequence'].next_by_code('litige.brv')

#     @api.one
#     @api.depends('date_debut')
#     def _compute_month(self):
#         if self.date_debut:
#             self.month = datetime.strftime(datetime.strptime(self.date_debut, "%Y-%m-%d"), '%m')

    ref_sec = fields.Char('Ref BRV', size=32, default=_get_default_name,)
    name = fields.Char('Num Chrono', size=32, required=True)
    code_fourni =fields.Integer('Fournisseur', required=True)
    libelle =fields.Char('Libelle',size=255)
    ref_invoice = fields.Char('Ref Facture')
    rayon =fields.Integer('Rayon')
    type_line = fields.Many2one('litige.type', string="Type line")
    no_reception =fields.Char('No Reception', size=32) 
    no_commande =fields.Float('No Commande', size=32) 
    date_commnade = fields.Date(string="Date Commande", default= time.strftime('%Y-%m-%d'))
    date_reception = fields.Date(string="Date Reception", default= time.strftime('%Y-%m-%d'))
    montant_ht= fields.Float("Montant HT" )
    montant_ttc= fields.Float("Montant TTC" )
    code_site =fields.Integer('Site')
    source =fields.Selection([('facture', 'Facture'), ('autres', 'Autres')], string='Source',default='facture',help='sources des lignes letigeuses')
    supplier = fields.Many2one('res.partner', string="Fournisseur", domain=[('supplier', '=', True)])
    user = fields.Many2one('litige.acheteur', string="Affecter a acheteur")
    note = fields.Text('Description')
    date_debut = fields.Date(string="Date Debut", default= time.strftime('%Y-%m-%d'))
    month = fields.Selection(
        [('01', 'Janvier'), ('02', 'fevrier'), ('03', 'Mars'), ('04', 'Avril'), ('05', 'Mai'), ('06', 'Juin'),
         ('07', 'Juillet'), ('08', 'Aout'), ('09', 'Septembre'), ('10', 'Octobre'), ('11', 'Novembre'),
         ('12', 'Decembre'), ], string='Mois', readonly=True, compute='_compute_month', store=True)
    date_fin = fields.Date(string="Date Fin")
    date_traiemant = fields.Date(string="Date traitement")
    cause = fields.Many2one('litige.type', string="Cause")
    linebrv_ids = fields.One2many('litige.brvlines', 'brvline_id', string="Lignes Bon Réveption Valorisé")
    state = fields.Selection(
        [('creer', 'Creer'), ('en_cours', 'En cours'), ('traiter', 'traiter'), ('cloturer', 'Cloturer')], 'Etat',
         default='creer')
    refund_count = fields.Integer( string='Avoir')

    @api.multi
    def act_en_cours(self):
        self.state = 'en_cours'

    @api.multi
    def act_traiter(self):
#         self.date_traiemant = time.strftime('%Y-%m-%d')
        self.state = 'traiter'

    @api.multi
    def act_cloturer(self):
#         self.date_fin = time.strftime('%Y-%m-%d')
        self.state = 'cloturer'

class LitigeBrvLigne(models.Model):
    @api.model
    def _get_default_name(self):
        return self.env['ir.sequence'].next_by_code('litige.brvligne')
    
    
    _name = "litige.brvlines"
    _description = "litige.brvlines"
    

    name = fields.Char('Ref brvlinge', size=32, default=_get_default_name,)
    brvline_id = fields.Many2one('litige.brv', string="Brv")
    code_article = fields.Char('Code article', size=32,)
    libelle = fields.Char('Libelle', size=255,)
    line_vl = fields.Integer('VL')
    line_ul = fields.Char('UL', size=32,)
    line_qte = fields.Float('Quantite')
    line_Montant = fields.Float('Montant')
    line_code_tva = fields.Integer('Code T.V.A.')
    line_tva = fields.Float('T.V.A.')
    line_type_doc = fields.Integer('Type document')
    line_doc = fields.Char('Libelle doc.', size=32,) 

class report_litige(models.Model):

    _name = "report.litige"
    _auto = False
    _description = "Rapport de litige"

    litige = fields.Integer('Litige', readonly=True)
    month = fields.Selection(
        [('01', 'Janvier'), ('02', 'fevrier'), ('03', 'Mars'), ('04', 'Avril'), ('05', 'Mai'), ('06', 'Juin'),
         ('07', 'Juillet'), ('08', 'Aout'), ('09', 'Septembre'), ('10', 'Octobre'), ('11', 'Novembre'),
         ('12', 'Decembre'), ], string='Periode', readonly=True)
    supplier = fields.Many2one('res.partner', string="Fournisseur", domain=[('supplier', '=', True)])
    cause = fields.Many2one('litige.type', string="Cause")
    state = fields.Selection(
        [('creer', 'Creer'), ('en_cours', 'En cours'), ('traiter', 'traiter'), ('cloturer', 'Cloturer')], 'Etat',
        readonly=True, default='creer')


    def init(self):
        tools.drop_view_if_exists(self._cr, 'report_litige')
        self._cr.execute("""
            CREATE OR REPLACE VIEW report_litige AS (
            select
                min(l.id) as id, 
                count(l.id) as litige,
                l.state as state,
                l.month as month,
                l.supplier as supplier,
                l.cause as cause
                From litige_litige l
            GROUP BY 
            l.state,l.month,l.supplier,l.cause

            )""")