# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Litige',
    'version': '1.1',
    'sequence': 75,
    'summary': '',
   
    'website': '',
    'images': [
        'static/src/img/default_image.png',
    ],
    'depends': ['base',
    ],
    'data': [
        'security/hr_security.xml',
        'security/ir.model.access.csv',
        'data/litige_sequence.xml',
        'views/litigesbrv_views.xml',
        'views/litige_views.xml',
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'qweb': [],
}
